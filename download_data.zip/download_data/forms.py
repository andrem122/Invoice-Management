from django import forms

#allows completed jobs to be downloaded in a spread sheet
class Download_Data_Form(forms.Form):
    pass
