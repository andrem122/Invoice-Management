from django.apps import AppConfig


class DownloadDataConfig(AppConfig):
    name = 'download_data'
